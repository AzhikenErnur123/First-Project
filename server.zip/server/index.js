const express = require('express');
const bodyParser = require('body-parser');
const jwt = require('jsonwebtoken');
const cors = require('cors');

const users = [
    { id: 2, email: "bolat@gmail.com", password: "bol123", username: "Bolat", isAdmin: true },
    { id: 3, email: "kasym@gmail.com", password: "kasym123", username: "Kasym", isAdmin: false }
];

const categories = [
    { id: 1, name: "КРУПНАЯ БЫТОВАЯ ТЕХНИКА" },
    { id: 2, name: "КОМПЬЮТЕРНАЯ ТЕХНИКА" },
    { id: 3, name: "ТЕЛЕВИЗОРЫ" },
    { id: 4, name: "КЛИМАТИЧЕСКАЯ ТЕХНИКА" },
];

const posts = [
    { id: 1, title: "Холодильник Haier MSR115", price: 500000, content: "Механический термостат,Стандартный компрессор,Класс А+,83,2/47,5/44,2 см,Гарантия 5 лет", tegi: "Холодильники", platform: "Артур Конан Дойл", userId: 1, categoryId: 1, url:"https://haieronline.kz/catalog/appliances/fridges/kholodilnik-haier-msr115/" },
    { id: 2, title: "Морозильный ларь Haier HCE100R", price: 140000, content: "Разморозка Static, Класс А+,Замораживание: 9 кг/сут, Объем 98 л, Гарантия 5 лет", tegi: "Морозильные камеры", platform: "Джейн Остин", userId: 1, categoryId: 1, url:"" },
    { id: 3, title: "СТИРАЛЬНАЯ МАШИНА HAIER HW60-BP12919B", price: 160000, content: "Загрузка 6 кг, Программа освежения паром, Скорость отжима 1200 об/мин, Инверторный мотор, Гарантия 5 лет", tegi: "Стиральные машины", platform: "Герман Мелвилл", userId: 1, categoryId: 1, url:""},
    { id: 4, title: "ТЕЛЕВИЗОР HAIER 32 SMART TV S1", price: 450000, content: "Диагональ 32, Full HD, Android TV,  DBX-TVб, HDR10", tegi: "Все телевизоры", platform: "Харпер Ли", userId: 2, categoryId: 3, url:"" },
    { id: 5, title: "Телевизор Haier 55 OLED S9 Ultra", price: 55000, content: "Диагональ 55, OLED, Google TV, Harman Kardon", tegi: "OLED", platform: "Брэм Стокер", userId: 2, categoryId: 3 , url:""},
    { id: 6, title: "Игровой компьютер Thunderobot Alpha D", price: 500000, content: "Процессор i5-12400, Видеокарта GTX 1650 4GB, 16 GB RAM 512 GB SSD, Без ОС", tegi: "Игровые компьютеры", platform: "Джордж Оруэлл", userId: 2, categoryId: 2, url:"" },
    { id: 7, title: "Игровой ноутбук Thunderobot 911S Core SD", price: 40000, content: "Экран 15.6, Full HD 144 ГЦ IPS, Видеокарта: RTX 3050 4GB, 8 GB RAM 512 GB SSD, Без ОС", tegi: "Игровые ноутбуки", platform: "ИДжордж Оруэлл", userId: 3, categoryId: 2, url:"" },
    { id: 8, title: "Франкенштейн", price: 450000, content: "Площадь помещения: до 20 м², Компрессор: Инверторный, Самоочистка кондиционера, Мин. температура в режиме обогрева: -15°С", tegi: "Кондиционеры", platform: "Мэри Шелли", userId: 3, categoryId: 4, url:"" },
];

const app = express();
const secretKey = 'token';

app.use(cors());
app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.post('/register', (req, res) => {
    const { email, password, username } = req.body;
    const existingUser = users.find(user => user.email === email);
    if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
    }
    const newUser = { id: users.length + 1, email, password, username, isAdmin: false };
    users.push(newUser);
    res.json({ message: `User ${username} was registered...` });
});

app.get('/categories', (req, res) => {
    res.json(categories);
});

app.get('/users', (req, res) => {
    res.json(users);
});

app.post('/login', (req, res) => {
    const { email, password } = req.body;
    const user = users.find(user => user.email === email && user.password === password);
    if (user) {
        const token = jwt.sign({ userId: user.id, isAdmin: user.isAdmin }, secretKey, { expiresIn: '1h' });
        res.json({ userId: user.id, username: user.username, isAdmin: user.isAdmin, token });
    } else {
        res.status(401).json({ message: "Wrong username or password..." });
    }
});

const checkToken = (req, res, next) => {
    const authValue = req.headers['authorization'];
    if (!authValue) {
        return res.status(401).json({ message: "Token not found..." });
    }
    const token = authValue.split(' ')[1];
    jwt.verify(token, secretKey, (err, value) => {
        if (err) {
            return res.status(401).json({ message: "Invalid Token..." });
        }
        req.userId = value.userId;
        req.isAdmin = value.isAdmin;
        next();
    });
};

const checkAdmin = (req, res, next) => {
    if (!req.isAdmin) {
        return res.status(403).json({ message: "Access forbidden: Admins only" });
    }
    next();
};

app.get('/privatePosts', checkToken, (req, res) => {
    const postsToSend = posts.filter(p => p.userId === req.userId);
    res.json(postsToSend);
});

app.get('/posts', (req, res) => {
    res.json(posts);
});

app.post('/posts/create', checkToken, (req, res) => {
    const { title, content, categoryId } = req.body;
    const newPost = { id: posts.length + 1, title, content, userId: req.userId, categoryId };
    posts.push(newPost);
    res.json({ message: `Post ${title} was created...` });
});

app.post('/categories/create', checkToken, checkAdmin, (req, res) => {
    const { name } = req.body;
    const newCategory = { id: categories.length + 1, name };
    categories.push(newCategory);
    res.json({ message: `Category ${name} created successfully...` });
});


app.get('/posts/category/:categoryId', (req, res) => {
    const postsToSend = posts.filter(p => p.categoryId == req.params.categoryId);
    res.json(postsToSend);
});

app.put('/categories/:categoryId', checkToken, (req, res) => {
    const categoryIndex = categories.findIndex(c => c.id == req.params.categoryId);
    if (categoryIndex !== -1) {
        categories[categoryIndex].name = req.body.name;
        res.json({ message: "Category updated successfully..." });
    } else {
        res.status(404).json({ message: "Category not found..." });
    }
});

app.delete('/posts/:postId', checkToken, (req, res) => {
    const postIndex = posts.findIndex(p => p.id == req.params.postId);
    if (postIndex !== -1) {
        const post = posts[postIndex];
        if (req.userId === post.userId || req.isAdmin) {
            posts.splice(postIndex, 1);
            res.json({ message: "Post deleted successfully..." });
        } else {
            res.status(403).json({ message: "Access forbidden: Only the creator or an admin can delete this post" });
        }
    } else {
        res.status(404).json({ message: "Post not found..." });
    }
});

app.delete('/categories/:categoryId', checkToken, checkAdmin, (req, res) => {
    const categoryIndex = categories.findIndex(c => c.id == req.params.categoryId);
    if (categoryIndex !== -1) {
        categories.splice(categoryIndex, 1);
        res.json({ message: "Category deleted successfully..." });
    } else {
        res.status(404).json({ message: "Category not found..." });
    }
});

app.get('/posts/:postId', (req, res) => {
    console.log("GET /posts/:postId requested");
    const postId = req.params.postId;
    const foundPost = posts.find(p => p.id == postId);
    if (foundPost) {
        res.json(foundPost);
    } else {
        res.status(404).json({ message: `Post with id=${postId} not found` });
    }
});

app.put('/posts/:postId', (checkToken || checkAdmin), (req, res) => {
    console.log("PUT /posts/:postId requested");
    const userId = req.userId;
    const postId = req.params.postId;
    const { title, content, categoryId } = req.body;
    const postIndex = posts.findIndex(p => p.id == postId);
    if (postIndex != -1) {
        posts[postIndex] = { id: postId, title, content, categoryId, userId };
        res.json({ message: `Post ${title} was edited...` });
    } else {
        res.status(404).json({ error: 'Post is not found' });
    }
});

app.listen(3005, () => {
    console.log('Server started on port ...');
});
